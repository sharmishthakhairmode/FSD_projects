# Appointment-Scheduling-System
online appointment booking system with notifications using HTML, CSS, and JavaScript.
