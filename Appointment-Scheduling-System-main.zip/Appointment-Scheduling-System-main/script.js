let appointments = [];

// 🔔 Browser Notification Function
function showNotification(message) {
  if ("Notification" in window) {
    if (Notification.permission === "granted") {
      new Notification(message);
    } else if (Notification.permission !== "denied") {
      Notification.requestPermission().then(permission => {
        if (permission === "granted") {
          new Notification(message);
        } else {
          alert(message); // fallback
        }
      });
    } else {
      alert(message); // fallback
    }
  } else {
    alert(message); // fallback
  }
}

// 🔊 Sound
function playSound() {
  let audio = new Audio("https://www.soundjay.com/buttons/sounds/button-3.mp3");
  audio.play();
}

// 📌 Book Appointment
function bookAppointment() {

  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  let date = document.getElementById("date").value;
  let time = document.getElementById("time").value;
  let service = document.getElementById("service").value;

  let notification = document.getElementById("notification");

  if (!name || !email || !date || !time || !service) {
    notification.style.color = "red";
    notification.innerText = "⚠ Please fill all fields!";
    return;
  }

  let appointment = { name, email, date, time, service };
  appointments.push(appointment);

  // UI message
  notification.style.color = "green";
  notification.innerText = "✅ Appointment Booked!";

  // 🔔 Real notification + sound
  showNotification("📅 Appointment Confirmed!");
  playSound();

  displayAppointments();
  clearFields();
}

// 📋 Display Appointments
function displayAppointments() {
  let container = document.getElementById("appointments");
  container.innerHTML = "";

  appointments.forEach((app, index) => {
    container.innerHTML += `
      <div style="border-bottom:1px solid #ccc; padding:10px;">
        <p><b>${app.name}</b> - ${app.service}</p>
        <p>${app.date} at ${app.time}</p>
        <button onclick="deleteAppointment(${index})">Delete</button>
      </div>
    `;
  });
}

// ❌ Delete Appointment
function deleteAppointment(index) {
  appointments.splice(index, 1);
  displayAppointments();
}

// 🔄 Clear Fields
function clearFields() {
  document.getElementById("name").value = "";
  document.getElementById("email").value = "";
  document.getElementById("date").value = "";
  document.getElementById("time").value = "";
  document.getElementById("service").value = "";
}