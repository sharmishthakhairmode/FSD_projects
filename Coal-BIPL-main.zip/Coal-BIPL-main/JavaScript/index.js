const navMainBg = document.querySelector('.nav__main__bg');
const toggleBtn = document.querySelector('.toggle__btn');

toggleBtn.addEventListener('click', () => {
    navMainBg.classList.toggle('nav__main__height');
})

