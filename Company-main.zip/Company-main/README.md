# Company
A professional, multi-page static website for a fictional company built with Next.js and TypeScript. Includes Home, About, Services, and Contact pages styled with Tailwind CSS and ShadCN UI. Features a working admin panel to manage contact form submissions.
