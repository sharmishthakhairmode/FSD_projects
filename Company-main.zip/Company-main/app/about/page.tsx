import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Award, Target, Eye, Heart } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="flex flex-col">

      {/* Hero Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-br from-background to-muted text-center animate-fade-in-up">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-4">About InnovateTech Solutions</Badge>
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl text-balance animate-fade-in-up">
            Pioneering the Future of <span className="text-primary">Technology</span>
          </h1>
          <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-3xl mx-auto animate-fade-in-up">
            Since 2015, we’ve helped businesses grow, work smarter, and achieve more with simple and effective technology solutions.
          </p>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl mb-6">Our Story</h2>
              <div className="space-y-4 text-muted-foreground">
                <p>We started with a simple goal: make technology work for businesses, not the other way around.</p>
                <p>From a small consulting firm, we’ve grown into a trusted partner for companies of all sizes.</p>
                <p>Our approach is practical, focused, and always tailored to our clients’ needs.</p>
              </div>
            </div>
            <div className="relative animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
              <div className="aspect-square bg-gradient-to-br from-primary/20 to-secondary/20 rounded-2xl flex items-center justify-center animate-float">
                <div className="text-center p-8">
                  <div className="text-6xl font-bold text-primary mb-4">9+</div>
                  <div className="text-xl font-semibold text-foreground mb-2">Years of Experience</div>
                  <div className="text-muted-foreground">Helping businesses succeed since 2015</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission, Vision, Values */}
      <section className="py-20 bg-muted">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">What Drives Us</h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              Simple principles that guide our work every day.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Our Mission", icon: Target, text: "Help businesses achieve more with simple, practical technology solutions." },
              { title: "Our Vision", icon: Eye, text: "Be the trusted partner for companies seeking meaningful digital transformation." },
              { title: "Our Values", icon: Heart, text: "Integrity, curiosity, collaboration, and client success." },
            ].map((item, i) => (
              <Card key={i} className="border-border hover:shadow-md transition-all animate-fade-in-up" style={{ animationDelay: `${i * 0.2}s` }}>
                <CardHeader className="text-center">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <item.icon className="h-8 w-8 text-primary" />
                  </div>
                  <CardTitle className="text-2xl">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-center text-base">{item.text}</CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Leadership Team */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Our Team</h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              Meet the people behind our work.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { initials: "JS", name: "John Smith", role: "CEO" },
              { initials: "SJ", name: "Sarah Johnson", role: "CTO" },
              { initials: "MD", name: "Michael Davis", role: "COO" },
            ].map((member, i) => (
              <Card key={i} className="border-border text-center hover-lift animate-fade-in-up" style={{ animationDelay: `${i * 0.2}s` }}>
                <CardHeader>
                  <div className="w-24 h-24 bg-gradient-to-br from-primary/20 to-secondary/20 rounded-full mx-auto mb-4 flex items-center justify-center animate-float">
                    <span className="text-2xl font-bold text-primary">{member.initials}</span>
                  </div>
                  <CardTitle>{member.name}</CardTitle>
                  <CardDescription>{member.role}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20 bg-muted">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">Our Achievements</h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto">
              Highlights of our journey so far.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { title: "Industry Awards", desc: "Recognized as Technology Partner of the Year", icon: <Award className="h-8 w-8 text-primary" /> },
              { title: "Certified", desc: "ISO 27001 certified", icon: <div className="text-3xl font-bold text-primary">ISO</div> },
              { title: "Uptime", desc: "Reliable services with 99.9% uptime", icon: <div className="text-3xl font-bold text-primary">99.9%</div> },
              { title: "Transactions", desc: "50M+ processed annually", icon: <div className="text-3xl font-bold text-primary">50M+</div> },
            ].map((item, i) => (
              <div key={i} className="text-center animate-fade-in-up" style={{ animationDelay: `${i * 0.15}s` }}>
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
                  {item.icon}
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-primary text-center animate-fade-in-up">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl mb-4">Let’s Work Together</h2>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto mb-8">
            We love solving problems with technology. Reach out and let’s start your next project.
          </p>
          <Button variant="secondary" size="lg" asChild>
            <Link href="/contact">Get in Touch</Link>
          </Button>
        </div>
      </section>
    </div>
  )
}


