"use client"

import { useEffect, useState } from "react"
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

export default function AdminPage() {
  const [messages, setMessages] = useState<any[]>([])

  useEffect(() => {
    fetch("/api/messages")
      .then((res) => res.json())
      .then((data) => {
        console.log("Fetched messages:", data) // 👈 debugging log
        setMessages(data)
      })
      .catch((err) => console.error("Error fetching messages:", err))
  }, [])

  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-8">Admin Panel</h1>

      {messages.length === 0 && <p>No messages sent yet.</p>}

      <div className="space-y-4">
        {messages.map((msg, i) => (
          <Card key={i}>
            <CardHeader>
              <CardTitle>
                {msg.name} ({msg.email})
              </CardTitle>
            </CardHeader>
            <CardContent>{msg.message}</CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}

