import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

const filePath = path.join(process.cwd(), "messages.json");

export async function POST(req: NextRequest) {
  try {
    const { name, email, message } = await req.json();

    if (!name || !email || !message) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    // Read existing messages
    let messages = [];
    try {
      const data = await fs.readFile(filePath, "utf-8");
      messages = JSON.parse(data);
    } catch {
      messages = [];
    }

    // Add new message
    const newMessage = { name, email, message };
    messages.push(newMessage);

    // Save back to file
    await fs.writeFile(filePath, JSON.stringify(messages, null, 2));

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

export async function GET() {
  try {
    const data = await fs.readFile(filePath, "utf-8");
    const messages = JSON.parse(data);
    return NextResponse.json(messages);
  } catch {
    return NextResponse.json([]);
  }
}
