"use client"
import type React from "react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Phone, MapPin } from "lucide-react"

export default function ContactPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    service: "",
    message: "",
  })

  const [status, setStatus] = useState("")

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

 const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();

  const res = await fetch("/api/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      name: formData.name,
      email: formData.email,
      message: formData.message,
    }),
  });

  if (res.ok) {
    alert("✅ Message sent!");
  } else {
    alert("❌ Failed to send message");
  }
};



  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-br from-background to-muted text-center">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-4 animate-fade-in-up">Contact Us</Badge>
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl animate-fade-in-up">
            Let's Start Your <span className="text-primary">Digital Transformation</span>
          </h1>
          <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-3xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Ready to take your business to the next level? Get in touch with our team of experts.
          </p>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="animate-slide-in-left">
              <Card className="border-border hover-lift">
                <CardHeader>
                  <CardTitle className="text-2xl">Send Us a Message</CardTitle>
                  <CardDescription>We'll get back to you within 24 hours.</CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2 animate-fade-in-up">
                        <Label htmlFor="name">Full Name *</Label>
                        <Input id="name" type="text" placeholder="Enter your name"
                          value={formData.name}
                          onChange={(e) => handleInputChange("name", e.target.value)}
                          required />
                      </div>
                      <div className="space-y-2 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
                        <Label htmlFor="email">Email Address *</Label>
                        <Input id="email" type="email" placeholder="Enter your Email"
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          required />
                      </div>
                    </div>
                    <div className="space-y-2 animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
                      <Label htmlFor="company">Company Name</Label>
                      <Input id="company" type="text" placeholder="Your Company Inc."
                        value={formData.company}
                        onChange={(e) => handleInputChange("company", e.target.value)} />
                    </div>
                    <div className="space-y-2 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
                      <Label htmlFor="service">Service Interest</Label>
                      <Select onValueChange={(value) => handleInputChange("service", value)} value={formData.service}>
                        <SelectTrigger><SelectValue placeholder="Select a service" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="cloud-solutions">Cloud Solutions</SelectItem>
                          <SelectItem value="software-development">Custom Software Development</SelectItem>
                          <SelectItem value="digital-transformation">Digital Transformation</SelectItem>
                          <SelectItem value="cybersecurity">Cybersecurity Services</SelectItem>
                          <SelectItem value="data-analytics">Data Analytics & BI</SelectItem>
                          <SelectItem value="mobile-development">Mobile App Development</SelectItem>
                          <SelectItem value="consulting">IT Consulting</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2 animate-fade-in-up" style={{ animationDelay: "0.5s" }}>
                      <Label htmlFor="message">Message *</Label>
                      <Textarea id="message" placeholder="Tell us about your project..." rows={5}
                        value={formData.message}
                        onChange={(e) => handleInputChange("message", e.target.value)}
                        required />
                    </div>
                    <Button type="submit" size="lg" className="w-full hover-glow animate-fade-in-up" style={{ animationDelay: "0.6s" }}>
                      Send Message →
                    </Button>
                  </form>
                  {status && <p className="mt-4">{status}</p>}
                </CardContent>
              </Card>
            </div>

            {/* Contact Information */}
            <div className="space-y-8 animate-slide-in-right">
              <h2 className="text-2xl font-bold text-foreground mb-6 animate-fade-in-up">Get in Touch</h2>
              <p className="text-muted-foreground mb-8 animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
                Reach out to us through any of the channels below.
              </p>
              <Card className="border-border bg-muted hover-lift animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
                <CardHeader>
                  <CardTitle className="text-lg">Need Immediate Assistance?</CardTitle>
                  <CardDescription>For urgent technical support or emergencies, contact our 24/7 support line.</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full bg-transparent hover-glow">
                    <Phone className="mr-2 h-4 w-4" />
                    Emergency Support: +1 (555) 999-0000
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-background animate-fade-in-up">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl animate-fade-in-up">Find Our Office</h2>
          <p className="mt-4 text-lg text-muted-foreground animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            Located in the heart of Innovation City's tech district.
          </p>
          <div className="bg-muted rounded-lg h-96 flex items-center justify-center hover-lift animate-fade-in-up" style={{ animationDelay: "0.3s" }}>
            <div className="text-center">
              <MapPin className="h-12 w-12 text-primary mx-auto mb-4 animate-float" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Interactive Map</h3>
              <p className="text-muted-foreground">123 Tech Street, Innovation City, IC 12345<br /><span className="text-sm">(Map integration would go here)</span></p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
