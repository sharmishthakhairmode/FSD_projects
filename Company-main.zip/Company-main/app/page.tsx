import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-background to-muted py-20 lg:py-32">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge variant="secondary" className="mb-4 animate-fade-in-up">
              Leading Technology Solutions
            </Badge>
            <h1
              className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl lg:text-7xl text-balance animate-fade-in-up"
              style={{ animationDelay: "0.2s" }}
            >
              Transform Your Business with{" "}
              <span className="text-primary animate-pulse-glow">Innovative Technology</span>
            </h1>
            <p
              className="mt-6 text-lg leading-8 text-muted-foreground max-w-3xl mx-auto text-pretty animate-fade-in-up"
              style={{ animationDelay: "0.4s" }}
            >
              We help businesses accelerate their digital transformation journey with cutting-edge cloud solutions,
              custom software development, and strategic IT consulting services.
            </p>
            <div
              className="mt-10 flex items-center justify-center gap-x-6 animate-fade-in-up"
              style={{ animationDelay: "0.6s" }}
            >
              <Button asChild size="lg" className="hover-lift hover-glow">
                <Link href="/contact">Get Started Today →</Link>
              </Button>
              <Button variant="outline" size="lg" asChild className="hover-lift bg-transparent">
                <Link href="/services">Learn More</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-in-left">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
              Why Choose InnovateTech?
            </h2>
            <p className="mt-4 text-lg text-muted-foreground max-w-2xl mx-auto text-pretty">
              We combine technical expertise with business acumen to deliver solutions that drive real results.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card
              className="border-border hover:shadow-lg transition-shadow hover-lift animate-fade-in-up"
              style={{ animationDelay: "0.1s" }}
            >
              <CardHeader>
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float">
                  <span className="text-2xl">☁️</span>
                </div>
                <CardTitle>Cloud Excellence</CardTitle>
                <CardDescription>
                  Seamless migration and optimization of your infrastructure with leading cloud platforms.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card
              className="border-border hover:shadow-lg transition-shadow hover-lift animate-fade-in-up"
              style={{ animationDelay: "0.2s" }}
            >
              <CardHeader>
                <div
                  className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float"
                  style={{ animationDelay: "0.5s" }}
                >
                  <span className="text-2xl">💻</span>
                </div>
                <CardTitle>Custom Development</CardTitle>
                <CardDescription>
                  Tailored software solutions built with modern technologies to meet your unique business needs.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card
              className="border-border hover:shadow-lg transition-shadow hover-lift animate-fade-in-up"
              style={{ animationDelay: "0.3s" }}
            >
              <CardHeader>
                <div
                  className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float"
                  style={{ animationDelay: "1s" }}
                >
                  <span className="text-2xl">⚡</span>
                </div>
                <CardTitle>Digital Transformation</CardTitle>
                <CardDescription>
                  Strategic guidance to modernize your operations and accelerate business growth.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card
              className="border-border hover:shadow-lg transition-shadow hover-lift animate-fade-in-up"
              style={{ animationDelay: "0.4s" }}
            >
              <CardHeader>
                <div
                  className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float"
                  style={{ animationDelay: "1.5s" }}
                >
                  <span className="text-2xl">🛡️</span>
                </div>
                <CardTitle>Security First</CardTitle>
                <CardDescription>
                  Enterprise-grade security measures to protect your data and ensure compliance.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card
              className="border-border hover:shadow-lg transition-shadow hover-lift animate-fade-in-up"
              style={{ animationDelay: "0.5s" }}
            >
              <CardHeader>
                <div
                  className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float"
                  style={{ animationDelay: "2s" }}
                >
                  <span className="text-2xl">👥</span>
                </div>
                <CardTitle>Expert Team</CardTitle>
                <CardDescription>
                  Certified professionals with deep expertise across multiple technology domains.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card
              className="border-border hover:shadow-lg transition-shadow hover-lift animate-fade-in-up"
              style={{ animationDelay: "0.6s" }}
            >
              <CardHeader>
                <div
                  className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float"
                  style={{ animationDelay: "2.5s" }}
                >
                  <span className="text-2xl">📈</span>
                </div>
                <CardTitle>Proven Results</CardTitle>
                <CardDescription>
                  Track record of successful projects delivering measurable business value.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-muted">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16 animate-slide-in-right">
            <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl text-balance">
              Trusted by Industry Leaders
            </h2>
            <p className="mt-4 text-lg text-muted-foreground text-pretty">
              Our solutions have helped hundreds of companies achieve their digital transformation goals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center animate-fade-in-up hover-lift" style={{ animationDelay: "0.1s" }}>
              <div className="text-4xl font-bold text-primary mb-2 animate-pulse-glow">500+</div>
              <div className="text-muted-foreground">Projects Completed</div>
            </div>
            <div className="text-center animate-fade-in-up hover-lift" style={{ animationDelay: "0.2s" }}>
              <div
                className="text-4xl font-bold text-primary mb-2 animate-pulse-glow"
                style={{ animationDelay: "0.5s" }}
              >
                98%
              </div>
              <div className="text-muted-foreground">Client Satisfaction</div>
            </div>
            <div className="text-center animate-fade-in-up hover-lift" style={{ animationDelay: "0.3s" }}>
              <div className="text-4xl font-bold text-primary mb-2 animate-pulse-glow" style={{ animationDelay: "1s" }}>
                50+
              </div>
              <div className="text-muted-foreground">Expert Consultants</div>
            </div>
            <div className="text-center animate-fade-in-up hover-lift" style={{ animationDelay: "0.4s" }}>
              <div
                className="text-4xl font-bold text-primary mb-2 animate-pulse-glow"
                style={{ animationDelay: "1.5s" }}
              >
                24/7
              </div>
              <div className="text-muted-foreground">Support Available</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary animate-pulse-glow">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl text-balance animate-fade-in-up">
            Ready to Transform Your Business?
          </h2>
          <p
            className="mt-4 text-lg text-primary-foreground/90 max-w-2xl mx-auto text-pretty animate-fade-in-up"
            style={{ animationDelay: "0.2s" }}
          >
            Let's discuss how our technology solutions can help you achieve your business objectives and stay ahead of
            the competition.
          </p>
          <div className="mt-8 animate-fade-in-up" style={{ animationDelay: "0.4s" }}>
            <Button variant="secondary" size="lg" asChild className="hover-lift hover-glow">
              <Link href="/contact">Start Your Journey →</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
