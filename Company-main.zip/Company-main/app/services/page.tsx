import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import {
  Cloud,
  Code,
  Zap,
  Shield,
  Database,
  Smartphone,
  BarChart3,
  Headphones,
  ArrowRight,
  CheckCircle,
} from "lucide-react"

export default function ServicesPage() {
  const services = [
    {
      icon: Cloud,
      title: "Cloud Solutions",
      description: "We help you move your business to the cloud smoothly and securely.",
      features: ["AWS, Azure, GCP expertise", "Migration planning & execution", "Cost optimization", "24/7 monitoring"],
      pricing: "Starting at $5,000/month",
    },
    {
      icon: Code,
      title: "Custom Software Development",
      description: "Tailored apps that fit your business needs and scale with you.",
      features: ["Full-stack development", "API integration", "Scalable architecture", "Quality assurance"],
      pricing: "Starting at $15,000/project",
    },
    {
      icon: Zap,
      title: "Digital Transformation",
      description: "Modernizing your processes to work smarter, not harder.",
      features: ["Process automation", "Legacy system modernization", "Change management", "ROI optimization"],
      pricing: "Custom pricing",
    },
    {
      icon: Shield,
      title: "Cybersecurity Services",
      description: "Protect your digital assets with reliable security solutions.",
      features: ["Security audits", "Compliance management", "Threat monitoring", "Incident response"],
      pricing: "Starting at $3,000/month",
    },
    {
      icon: Database,
      title: "Data Analytics & BI",
      description: "Turn your data into actionable insights for smarter decisions.",
      features: ["Data warehousing", "Business intelligence", "Predictive analytics", "Custom dashboards"],
      pricing: "Starting at $8,000/project",
    },
    {
      icon: Smartphone,
      title: "Mobile App Development",
      description: "Apps that your customers love, on iOS and Android.",
      features: ["Native iOS/Android", "React Native", "Flutter development", "App store optimization"],
      pricing: "Starting at $25,000/project",
    },
  ]

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="py-20 lg:py-32 bg-gradient-to-br from-background to-muted text-center animate-fade-in-up">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <Badge variant="secondary" className="mb-4 animate-fade-in-up">Our Services</Badge>
          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-6xl text-balance animate-fade-in-up">
            Technology Solutions That Work For You
          </h1>
          <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-3xl mx-auto animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            From cloud migration to custom software, we provide services that help your business grow smarter and faster.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-background">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon
              return (
                <Card
                  key={index}
                  className="border-border hover:shadow-md transition-all hover-lift animate-fade-in-up"
                  style={{ animationDelay: `${index * 0.15}s`, animationFillMode: "both" }}
                >
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 animate-float">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle>{service.title}</CardTitle>
                    <CardDescription>{service.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2 mb-4">
                      {service.features.map((feature, i) => (
                        <li
                          key={i}
                          className="flex items-center text-sm text-muted-foreground animate-fade-in-up"
                          style={{ animationDelay: `${i * 0.1}s` }}
                        >
                          <CheckCircle className="h-4 w-4 text-primary mr-2" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-semibold text-primary">{service.pricing}</span>
                      <Button variant="outline" size="sm" asChild>
                        <Link href="/contact">Learn More</Link>
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-muted animate-fade-in-up">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl mb-4 animate-fade-in-up">How We Work</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-12 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            We follow a clear process to make sure your project succeeds.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {["Discovery", "Strategy", "Implementation", "Support"].map((step, i) => (
              <div key={i} className="text-center animate-fade-in-up" style={{ animationDelay: `${i * 0.15}s` }}>
                <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4 animate-float">
                  <span className="text-2xl font-bold text-primary-foreground">{i + 1}</span>
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">{step}</h3>
                <p className="text-sm text-muted-foreground">
                  {i === 0 && "We learn about your business and current challenges."}
                  {i === 1 && "We create a roadmap and strategy for your project."}
                  {i === 2 && "Our team implements the solution with transparency."}
                  {i === 3 && "We provide ongoing support and optimization."}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-center animate-fade-in-up">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold tracking-tight text-primary-foreground sm:text-4xl mb-4 animate-fade-in-up">Ready to Start Your Project?</h2>
          <p className="text-lg text-primary-foreground/90 max-w-2xl mx-auto mb-8 animate-fade-in-up" style={{ animationDelay: "0.1s" }}>
            Let's discuss your needs and create a solution that works for your business.
          </p>
          <Button variant="secondary" size="lg" asChild className="animate-fade-in-up" style={{ animationDelay: "0.2s" }}>
            <Link href="/contact">
              Contact Us
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}
