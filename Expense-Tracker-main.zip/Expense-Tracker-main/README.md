# Expense-Tracker
A simple and user-friendly expense tracker web application built using HTML, CSS, and JavaScript. This app helps users track their daily expenses, calculate the total amount spent, and manage expenses efficiently — without using any external APIs.
