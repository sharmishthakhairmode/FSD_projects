<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}
require 'db.php';

$totalPolls = $pdo->query("SELECT COUNT(*) FROM polls")->fetchColumn();
$totalUsers = $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
$pollsPerDay = $pdo->query("SELECT DATE(created_at) as day, COUNT(*) as count FROM polls GROUP BY day ORDER BY day DESC LIMIT 7")->fetchAll();
$votesPerPoll = $pdo->query("SELECT p.title, COUNT(v.id) as votes FROM polls p LEFT JOIN votes v ON p.id = v.poll_id GROUP BY p.id ORDER BY votes DESC LIMIT 5")->fetchAll();
$users = $pdo->query("SELECT id, name, email, created_at FROM users ORDER BY created_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            margin: 0;
            padding: 30px;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #fff5f5, #ffeaea);
            animation: fadeInBody 1s ease;
        }

        @keyframes fadeInBody {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        h2, h3, h4 {
            color: #550000;
        }

        .nav {
            margin-bottom: 30px;
        }

        .nav a {
            margin-right: 15px;
            padding: 8px 14px;
            background: #550000;
            color: white;
            border-radius: 6px;
            text-decoration: none;
            font-weight: bold;
            transition: background 0.3s ease;
        }

        .nav a:hover {
            background: #770000;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .box {
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
            animation: slideIn 0.8s ease forwards;
            opacity: 0;
        }

        @keyframes slideIn {
            to { opacity: 1; transform: translateY(0); }
            from { opacity: 0; transform: translateY(10px); }
        }

        canvas {
            max-width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
            font-size: 14px;
        }

        th, td {
            padding: 10px;
            border: 1px solid #eee;
        }

        th {
            background-color: #550000;
            color: white;
        }

        tr:hover {
            background: #fafafa;
        }

        ul {
            padding-left: 0;
            list-style: none;
        }

        li {
            padding: 6px 0;
            border-bottom: 1px solid #eee;
        }

        hr {
            border: none;
            border-top: 1px solid #ddd;
            margin: 20px 0;
        }
    </style>
</head>
<body>

<h2>📊 Admin Dashboard</h2>

<div class="nav">
    <a href="create_poll.php">+ Create Poll</a>
    <a href="index.php">🏠 Home</a>
    <a href="logout.php">🚪 Logout</a>
</div>

<div class="grid">

    <div class="box">
        <h3>📅 Polls Per Day (7 days)</h3>
        <canvas id="pollsPerDayChart"></canvas>
    </div>

    <div class="box">
        <h3>🏆 Top 5 Polls by Votes</h3>
        <canvas id="votesPerPollChart"></canvas>
    </div>

    <div class="box">
        <h3>📊 App Overview</h3>
        <canvas id="doughnutChart"></canvas>
        <ul>
            <li><strong>Total Polls:</strong> <?= $totalPolls ?></li>
            <li><strong>Total Users:</strong> <?= $totalUsers ?></li>
        </ul>
    </div>

</div>

<div class="box">
    <h3>👤 Registered Users</h3>
    <table>
        <tr><th>ID</th><th>Name</th><th>Email</th><th>Registered On</th></tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= $user['id'] ?></td>
            <td><?= htmlspecialchars($user['name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= date("d M Y, h:i A", strtotime($user['created_at'])) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<div class="box">
    <h3>📋 All Poll Results</h3>
    <?php
    $polls = $pdo->query("SELECT * FROM polls ORDER BY created_at DESC")->fetchAll();
    foreach ($polls as $poll):
        $options = $pdo->prepare("SELECT o.option_text, COUNT(v.id) as votes FROM poll_options o LEFT JOIN votes v ON o.id = v.option_id WHERE o.poll_id = ? GROUP BY o.id");
        $options->execute([$poll['id']]);
        $optionData = $options->fetchAll();
        $totalVotes = array_sum(array_column($optionData, 'votes'));
    ?>
    <div style="margin-top: 20px;">
        <h4><?= htmlspecialchars($poll['title']) ?></h4>
        <p>🗓️ Deadline: <?= date("d M Y, h:i A", strtotime($poll['deadline'])) ?> | 🗳️ Total Votes: <?= $totalVotes ?></p>
        <ul>
            <?php foreach ($optionData as $opt): ?>
            <li><?= htmlspecialchars($opt['option_text']) ?> — <strong><?= $opt['votes'] ?> votes</strong></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <hr>
    <?php endforeach; ?>
</div>

<script>
const pollData = <?= json_encode($pollsPerDay) ?>;
const voteData = <?= json_encode($votesPerPoll) ?>;

new Chart(document.getElementById("pollsPerDayChart"), {
    type: "line",
    data: {
        labels: pollData.map(p => p.day),
        datasets: [{
            label: "Polls per Day",
            data: pollData.map(p => p.count),
            borderColor: "#550000",
            backgroundColor: "rgba(85,0,0,0.1)",
            fill: true,
            tension: 0.4
        }]
    }
});

new Chart(document.getElementById("votesPerPollChart"), {
    type: "bar",
    data: {
        labels: voteData.map(v => v.title),
        datasets: [{
            label: "Votes",
            data: voteData.map(v => v.votes),
            backgroundColor: "#ffaa00"
        }]
    }
});

new Chart(document.getElementById("doughnutChart"), {
    type: "doughnut",
    data: {
        labels: ["Polls", "Users"],
        datasets: [{
            data: [<?= $totalPolls ?>, <?= $totalUsers ?>],
            backgroundColor: ["#550000", "#0077cc"]
        }]
    }
});
</script>

</body>
</html>
