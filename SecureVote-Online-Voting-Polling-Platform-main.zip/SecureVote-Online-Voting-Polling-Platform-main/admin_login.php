<?php
session_start();

// Hardcoded admin credentials
$admin_username = "admin";
$admin_password = "secret123";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input_user = $_POST['username'] ?? '';
    $input_pass = $_POST['password'] ?? '';

    if ($input_user === $admin_username && $input_pass === $admin_password) {
        $_SESSION['admin'] = true;
        header("Location: admin_dashboard.php");
        exit;
    } else {
        $error = "Invalid admin credentials.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        body {
            margin: 0;
            padding: 40px;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #fff0f0, #ffe6e6);
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
            animation: fadeInBody 1s ease;
        }

        @keyframes fadeInBody {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        form {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 350px;
            animation: fadeInCard 1s ease;
        }

        @keyframes fadeInCard {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }

        h2 {
            color: #550000;
            text-align: center;
            margin-bottom: 25px;
        }

        input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        input:focus {
            border-color: #550000;
            box-shadow: 0 0 8px #d19c9c;
            outline: none;
        }

        button {
            background: #550000;
            color: white;
            padding: 12px;
            font-weight: bold;
            font-size: 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s ease, transform 0.2s;
        }

        button:hover {
            background: #770000;
            transform: scale(1.03);
        }

        .error {
            color: red;
            font-weight: bold;
            text-align: center;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<form method="POST">
    <h2>🔒 Admin Login</h2>
    <input type="text" name="username" placeholder="Admin Username" required>
    <input type="password" name="password" placeholder="Admin Password" required>
    <button type="submit">Login</button>
    <?php if ($error): ?>
        <p class="error"><?= $error ?></p>
    <?php endif; ?>
</form>

</body>
</html>
