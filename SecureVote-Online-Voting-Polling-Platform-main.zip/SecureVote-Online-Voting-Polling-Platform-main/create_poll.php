<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit;
}
require_once 'db.php';

$success = "";
$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title']);
    $deadline = $_POST['deadline'];
    $options = array_filter(array_map('trim', $_POST['options'] ?? []));

    if (empty($title) || empty($deadline) || count($options) < 2) {
        $error = "Title, deadline and at least 2 options are required.";
    } else {
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("INSERT INTO polls (title, deadline, created_at) VALUES (?, ?, NOW())");
            $stmt->execute([$title, $deadline]);
            $poll_id = $pdo->lastInsertId();

            $opt_stmt = $pdo->prepare("INSERT INTO poll_options (poll_id, option_text) VALUES (?, ?)");
            foreach ($options as $opt) {
                $opt_stmt->execute([$poll_id, $opt]);
            }

            $pdo->commit();
            $success = "✅ Poll created successfully!";
        } catch (Exception $e) {
            $pdo->rollBack();
            $error = "❌ Failed to create poll.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Poll</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to bottom right, #fbeaea, #fff5f5);
            margin: 0;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            min-height: 100vh;
            animation: fadeIn 0.8s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .form-box {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 500px;
        }

        h2 {
            color: #550000;
            margin-bottom: 25px;
            text-align: center;
        }

        input[type="text"],
        input[type="datetime-local"],
        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 16px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 15px;
        }

        button {
            background-color: #550000;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: background 0.3s ease;
        }

        button:hover {
            background-color: #770000;
        }

        .message {
            margin-top: 15px;
            text-align: center;
            font-weight: bold;
        }

        .error {
            color: #d8000c;
            background: #ffd2d2;
            padding: 10px;
            border-radius: 6px;
        }

        .success {
            color: #270;
            background: #dff2bf;
            padding: 10px;
            border-radius: 6px;
        }
    </style>
</head>
<body>

<div class="form-box">
    <h2>📝 Create New Poll</h2>

    <form method="POST">
        <input type="text" name="title" placeholder="Poll Title or Question" required>
        <input type="datetime-local" name="deadline" required>

        <input type="text" name="options[]" placeholder="Option 1" required>
        <input type="text" name="options[]" placeholder="Option 2" required>
        <input type="text" name="options[]" placeholder="Option 3 (optional)">
        <input type="text" name="options[]" placeholder="Option 4 (optional)">
        <input type="text" name="options[]" placeholder="Option 5 (optional)">

        <button type="submit">📤 Create Poll</button>
    </form>

    <?php if ($error): ?>
        <div class="message error"><?= $error ?></div>
    <?php elseif ($success): ?>
        <div class="message success"><?= $success ?></div>
    <?php endif; ?>
</div>

</body>
</html>
