<?php

// Escape HTML output
function e($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

// Redirect to a given URL
function redirect($url) {
    header("Location: $url");
    exit;
}

// Check if user already voted in a poll
function hasUserVoted($pdo, $poll_id, $user_id) {
    $stmt = $pdo->prepare("SELECT 1 FROM votes WHERE poll_id = ? AND user_id = ?");
    $stmt->execute([$poll_id, $user_id]);
    return $stmt->fetchColumn() ? true : false;
}

// Get total vote count for a poll
function totalVotes($pdo, $poll_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM votes WHERE poll_id = ?");
    $stmt->execute([$poll_id]);
    return $stmt->fetchColumn();
}

// Get poll title by ID
function getPollTitle($pdo, $poll_id) {
    $stmt = $pdo->prepare("SELECT title FROM polls WHERE id = ?");
    $stmt->execute([$poll_id]);
    $row = $stmt->fetch();
    return $row ? $row['title'] : '';
}

?>
