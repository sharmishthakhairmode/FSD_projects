<?php
session_start();
require_once 'db.php';
require_once 'functions.php';

$stmt = $pdo->prepare("SELECT * FROM polls WHERE deadline > NOW() ORDER BY deadline ASC");
$stmt->execute();
$polls = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Voting & Polling App</title>
    <style>
        body {
            margin: 0;
            padding: 30px;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to bottom right, #ffe6e6, #fffafa);
            min-height: 100vh;
            animation: fadeBody 0.8s ease-in;
        }

        @keyframes fadeBody {
            from { opacity: 0; transform: scale(0.98); }
            to { opacity: 1; transform: scale(1); }
        }

        h1 {
            color: #550000;
            margin-bottom: 15px;
            text-align: center;
            font-size: 32px;
            animation: fadeInDown 1s ease;
        }

        @keyframes fadeInDown {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .nav {
            text-align: center;
            margin-bottom: 30px;
            animation: fadeIn 1s ease;
        }

        .nav a {
            margin: 0 10px;
            text-decoration: none;
            font-weight: bold;
            color: #550000;
            padding: 6px 12px;
            border-radius: 6px;
            transition: background 0.3s ease;
        }

        .nav a:hover {
            background: #ffd6d6;
        }

        .poll {
            background: white;
            padding: 20px;
            margin: 20px auto;
            max-width: 600px;
            border-left: 6px solid #550000;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
            animation: slideUp 0.5s ease forwards;
            opacity: 0;
            transform: translateY(30px);
        }

        .poll:nth-child(1) { animation-delay: 0.2s; }
        .poll:nth-child(2) { animation-delay: 0.4s; }
        .poll:nth-child(3) { animation-delay: 0.6s; }
        .poll:nth-child(4) { animation-delay: 0.8s; }

        @keyframes slideUp {
            to { opacity: 1; transform: translateY(0); }
        }

        .poll h3 {
            margin: 0 0 10px;
            color: #333;
        }

        .poll p {
            margin: 5px 0 12px;
            font-size: 14px;
            color: #777;
        }

        .poll a {
            display: inline-block;
            padding: 7px 14px;
            background: #550000;
            color: white;
            text-decoration: none;
            font-weight: bold;
            border-radius: 5px;
            transition: background 0.3s ease, transform 0.2s;
        }

        .poll a:hover {
            background: #770000;
            transform: scale(1.05);
        }

        .status {
            font-size: 13px;
            color: green;
            font-weight: bold;
        }

        .empty {
            text-align: center;
            font-size: 18px;
            color: #555;
            margin-top: 60px;
            animation: fadeIn 1s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    </style>
</head>
<body>

<h1>🗳️SecureVote: Online Voting & Polling Platform</h1>

<div class="nav">
    <?php if (isset($_SESSION['user_id'])): ?>
        👋 Welcome, <?= htmlspecialchars($_SESSION['user_name']) ?> |
        <a href="logout.php">Logout</a>
    <?php else: ?>
        <a href="user_register.php">Register</a>
        <a href="user_login.php">Login</a>
    <?php endif; ?>
    | <a href="admin_login.php">Admin Login</a>
</div>

<?php if (empty($polls)): ?>
    <div class="empty">⚠️ No active polls at the moment. Please check back later.</div>
<?php else: ?>
    <?php foreach ($polls as $i => $poll): ?>
        <div class="poll" style="animation-delay: <?= 0.2 + $i * 0.2 ?>s">
            <h3><?= htmlspecialchars($poll['title']) ?></h3>
            <p class="status">⏳ Deadline: <?= date("d M Y, h:i A", strtotime($poll['deadline'])) ?></p>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="vote.php?poll=<?= $poll['id'] ?>">✅ Vote Now</a>
            <?php else: ?>
                <a href="user_login.php">🔐 Login to Vote</a>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
<?php endif; ?>

</body>
</html>