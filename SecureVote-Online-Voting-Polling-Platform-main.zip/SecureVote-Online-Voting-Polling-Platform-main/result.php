<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}

require 'db.php';
require_once 'functions.php';

$poll_id = $_GET['poll'] ?? null;
if (!$poll_id) die("Poll ID missing.");

$stmt = $pdo->prepare("SELECT * FROM polls WHERE id = ?");
$stmt->execute([$poll_id]);
$poll = $stmt->fetch();
if (!$poll) die("Poll not found.");

$stmt = $pdo->prepare("
    SELECT po.option_text, COUNT(v.id) AS votes
    FROM poll_options po
    LEFT JOIN votes v ON po.id = v.option_id
    WHERE po.poll_id = ?
    GROUP BY po.id
");
$stmt->execute([$poll_id]);
$options = $stmt->fetchAll();

$labels = json_encode(array_column($options, 'option_text'));
$data = json_encode(array_column($options, 'votes'));
?>

<!DOCTYPE html>
<html>
<head>
    <title>Poll Results</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to bottom right, #fbeaea, #fff0f0);
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 40px 20px;
            animation: fadeIn 1s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .container {
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.08);
            max-width: 650px;
            width: 100%;
            text-align: center;
        }

        h2 {
            color: #550000;
            margin-bottom: 10px;
        }

        .meta {
            color: #555;
            margin-bottom: 30px;
            font-size: 14px;
        }

        canvas {
            margin: auto;
            max-width: 100%;
        }

        a {
            display: inline-block;
            margin-top: 20px;
            text-decoration: none;
            color: #550000;
            font-weight: bold;
            transition: color 0.3s ease;
        }

        a:hover {
            color: #880000;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>📊 Results for: <?= htmlspecialchars($poll['title']) ?></h2>
    <div class="meta">
        <p><strong>Deadline:</strong> <?= date("d M Y, h:i A", strtotime($poll['deadline'])) ?></p>
    </div>

    <canvas id="resultChart"></canvas>

    <a href="index.php">← Back to Polls</a>
</div>

<script>
const ctx = document.getElementById('resultChart');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= $labels ?>,
        datasets: [{
            label: 'Votes',
            data: <?= $data ?>,
            backgroundColor: '#550000',
            borderRadius: 6,
            barThickness: 40
        }]
    },
    options: {
        responsive: true,
        animation: {
            duration: 1200,
            easing: 'easeOutQuart'
        },
        plugins: {
            legend: { display: false },
            tooltip: {
                backgroundColor: '#550000',
                titleFont: { weight: 'bold' },
                bodyFont: { size: 14 },
                padding: 10
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                ticks: {
                    stepSize: 1,
                    color: "#444"
                },
                grid: {
                    color: "#eee"
                }
            },
            x: {
                ticks: { color: "#444" },
                grid: { display: false }
            }
        }
    }
});
</script>

</body>
</html>
