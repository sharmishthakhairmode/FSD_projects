<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: user_login.php");
    exit;
}

require_once 'db.php';
require_once 'functions.php';

$poll_id = $_GET['poll'] ?? null;
if (!$poll_id) die("Poll ID missing.");

$stmt = $pdo->prepare("SELECT * FROM polls WHERE id = ?");
$stmt->execute([$poll_id]);
$poll = $stmt->fetch();

if (!$poll) die("Poll not found.");
if (strtotime($poll['deadline']) < time()) die("This poll has ended.");

$stmt = $pdo->prepare("SELECT id FROM votes WHERE poll_id = ? AND user_id = ?");
$stmt->execute([$poll_id, $_SESSION['user_id']]);
if ($stmt->fetch()) {
    header("Location: result.php?poll=$poll_id");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['option'])) {
    $option_id = intval($_POST['option']);
    $stmt = $pdo->prepare("INSERT INTO votes (poll_id, option_id, user_id, created_at) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$poll_id, $option_id, $_SESSION['user_id']]);
    header("Location: result.php?poll=$poll_id");
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM poll_options WHERE poll_id = ?");
$stmt->execute([$poll_id]);
$options = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vote Now</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #fce4ec, #f3e5f5);
            font-family: 'Segoe UI', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            animation: fadeIn 1s ease-in;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        form {
            background: #fff;
            padding: 30px;
            width: 100%;
            max-width: 480px;
            border-radius: 12px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.1);
            animation: slideUp 0.6s ease-out;
        }

        @keyframes slideUp {
            from { transform: translateY(40px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        h2 {
            color: #550000;
            margin-bottom: 10px;
        }

        p {
            color: #444;
            margin-bottom: 25px;
        }

        label {
            display: block;
            background: #f9f9f9;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 12px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: all 0.3s ease;
        }

        input[type="radio"] {
            margin-right: 10px;
        }

        input[type="radio"]:checked + span {
            font-weight: bold;
            color: #550000;
        }

        input[type="radio"]:focus-visible + span {
            outline: 2px solid #550000;
        }

        label:hover {
            background: #f1f1f1;
        }

        input[type="radio"] {
            display: none;
        }

        input[type="radio"]:checked ~ label {
            border-color: #550000;
            background: #fff5f7;
        }

        button {
            width: 100%;
            background: #550000;
            color: white;
            border: none;
            padding: 14px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 8px;
            margin-top: 20px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        button:hover {
            background: #770000;
        }
    </style>
</head>
<body>

<form method="POST">
    <h2>🗳️ <?= htmlspecialchars($poll['title']) ?></h2>
    <p>📅 Deadline: <?= date("d M Y, h:i A", strtotime($poll['deadline'])) ?></p>

    <?php foreach ($options as $opt): ?>
        <div>
            <input type="radio" id="opt<?= $opt['id'] ?>" name="option" value="<?= $opt['id'] ?>" required>
            <label for="opt<?= $opt['id'] ?>"><span><?= htmlspecialchars($opt['option_text']) ?></span></label>
        </div>
    <?php endforeach; ?>

    <button type="submit">Submit Vote</button>
</form>

</body>
</html>
