import { Link } from "react-router-dom";
import { categories } from "../data/categories";

export default function Navbar() {
  return (
    <header className="nav">
      <div className="container navInner">
        <Link to="/" className="logo">BIY</Link>

        <nav className="navLinks">
          {categories.map((c) => (
            <Link key={c} to={`/category/${encodeURIComponent(c)}`} className="navLink">
              {c}
            </Link>
          ))}
        </nav>

        <div className="navRight">
          <button className="iconBtn" aria-label="Search">⌕</button>
          <button className="iconBtn" aria-label="Bag">👜</button>
        </div>
      </div>
    </header>
  );
}
