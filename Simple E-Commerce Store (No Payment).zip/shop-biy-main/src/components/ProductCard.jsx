import { Link } from "react-router-dom";

export default function ProductCard({ product }) {
  return (
    <Link to={`/product/${product.id}`} className="card">
      <div className="cardImgWrap">
        <img className="cardImg" src={product.image} alt={product.title} />
      </div>
      <div className="cardBody">
        <div className="cardTitle">{product.title}</div>
        <div className="cardPrice">${product.price.toFixed(2)}</div>
        <div className="cardDesc">{product.description}</div>
      </div>
    </Link>
  );
}
