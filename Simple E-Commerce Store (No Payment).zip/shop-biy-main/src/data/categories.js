export const categories = ["Books", "Furniture", "Accessories", "Other"];


