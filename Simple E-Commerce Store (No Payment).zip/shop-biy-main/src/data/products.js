export const products = [
    {
      id: "yoga-mat-001",
      title: "Yoga Mat",
      category: "Accessories",
      price: 48.0,
      description: "Grippy, cushioned mat for studio or home.",
      image: "/images/yoga-mat.jpg",
      paypalUrl: "https://YOUR_PAYPAL_PAYMENT_LINK_HERE"
    },
    {
      id: "tank-001",
      title: "Training Tank",
      category: "Women",
      price: 38.0,
      description: "Lightweight tank for training sessions.",
      image: "/images/tank.jpg",
      paypalUrl: "https://YOUR_PAYPAL_PAYMENT_LINK_HERE"
    }
  ];
  