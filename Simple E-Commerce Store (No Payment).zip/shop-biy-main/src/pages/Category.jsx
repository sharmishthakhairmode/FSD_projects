import { useParams } from "react-router-dom";
import { products } from "../data/products";
import ProductCard from "../components/ProductCard";

export default function Category() {
  const { categoryName } = useParams();
  const decoded = decodeURIComponent(categoryName);

  const filtered = products.filter(p => p.category === decoded);

  return (
    <main className="container section">
      <h1 className="pageTitle">{decoded}</h1>
      <div className="grid products">
        {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
      </div>
      {filtered.length === 0 && (
        <p className="muted">No items in this category yet.</p>
      )}
    </main>
  );
}
