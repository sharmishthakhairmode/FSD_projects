import { Link } from "react-router-dom";
import { categories } from "../data/categories";
import { products } from "../data/products";
import ProductCard from "../components/ProductCard";

export default function Home() {
  return (
    <main>
      {/* HERO */}
      <section className="hero">
        <div className="container heroInner centerText">
          <h1 className="heroTitle">New gear for your next session</h1>
          <p className="heroSub">
            Clean essentials. Simple checkout with PayPal.
          </p>

          <div className="heroBtns">
            <Link
              className="btn"
              to={`/category/${encodeURIComponent("New Arrivals")}`}
            >
              Shop New
            </Link>
            <Link
              className="btn secondary"
              to={`/category/${encodeURIComponent("Accessories")}`}
            >
              Shop Accessories
            </Link>
          </div>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="section">
        <div className="container centerText">
          <h2 className="sectionTitle">Shop by category</h2>

          <div className="catRow centerRow">
            {categories.map((c) => (
              <Link
                key={c}
                className="catTile"
                to={`/category/${encodeURIComponent(c)}`
                }
              >
                {c}
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED */}
      <section className="section">
        <div className="container">
          <h2 className="sectionTitle centerText">Featured</h2>

          <div className="grid products centerGrid">
            {products.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
