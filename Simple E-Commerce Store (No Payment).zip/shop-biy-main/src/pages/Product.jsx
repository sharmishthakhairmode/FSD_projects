import { useParams } from "react-router-dom";
import { products } from "../data/products";

export default function Product() {
  const { productId } = useParams();
  const product = products.find(p => p.id === productId);

  if (!product) return <main className="container section">Not found.</main>;

  return (
    <main className="container section productPage">
      <div className="productGrid">
        <div className="productImgWrap">
          <img className="productImg" src={product.image} alt={product.title} />
        </div>

        <div>
          <h1 className="pageTitle">{product.title}</h1>
          <div className="bigPrice">${product.price.toFixed(2)}</div>
          <p className="productDesc">{product.description}</p>

          <a
            className="btn"
            href={product.paypalUrl}
            target="_blank"
            rel="noreferrer"
          >
            Buy with PayPal
          </a>

          <div className="finePrint">
            You’ll complete checkout securely on PayPal. We don’t store payment info.
          </div>
        </div>
      </div>
    </main>
  );
}
