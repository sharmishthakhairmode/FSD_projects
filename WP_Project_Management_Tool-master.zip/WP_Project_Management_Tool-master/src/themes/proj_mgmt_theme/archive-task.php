<?
echo 'silence is golden.';